import torch
import torch.nn as nn
import torch.nn.functional as F


class WingLoss(nn.Module):
    """Wing Loss - More robust than MSE for medical landmark detection.

    w=10, epsilon=2 as recommended for cephalometric landmarks.
    """

    def __init__(self, w=10.0, epsilon=2.0):
        super().__init__()
        self.w = w
        self.epsilon = epsilon
        self.C = w - w * (1.0 / (1.0 + w / epsilon))

    def forward(self, pred, target):
        """
        Args:
            pred: (N, num_landmarks, 2) predicted coordinates
            target: (N, num_landmarks, 2) ground truth coordinates
        Returns:
            Scalar loss value.
        """
        diff = torch.abs(pred - target)
        loss = torch.where(
            diff < self.w,
            self.w * torch.log(1.0 + diff / self.epsilon),
            diff - self.C
        )
        return loss.mean()


class CombinedLoss(nn.Module):
    """Combined MSE (heatmaps) + WingLoss (coordinates).

    lambda_wing controls WingLoss weight.
    """

    def __init__(self, lambda_wing=0.1):
        super().__init__()
        self.mse = nn.MSELoss()
        self.wing = WingLoss(w=10.0, epsilon=2.0)
        self.lambda_wing = lambda_wing

    def forward(self, pred_heatmaps, target_heatmaps, pred_coords=None, target_coords=None):
        """
        Args:
            pred_heatmaps: (N, 29, 144, 184)
            target_heatmaps: (N, 29, 144, 184)
            pred_coords: Optional (N, 29, 2) for WingLoss
            target_coords: Optional (N, 29, 2) for WingLoss
        """
        mse_loss = self.mse(pred_heatmaps, target_heatmaps)

        if pred_coords is not None and target_coords is not None:
            wing_loss = self.wing(pred_coords, target_coords)
            return mse_loss + self.lambda_wing * wing_loss

        return mse_loss
