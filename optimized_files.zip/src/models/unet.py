import torch
import torch.nn as nn
import segmentation_models_pytorch as smp


class UNetResNet50(nn.Module):
    """UNet with ResNet50 encoder for cephalometric landmark detection.

    Input: (N, 1, 576, 736) - (N, C, H, W) PyTorch convention
    Output: (N, 29, 144, 184) - (N, C, H, W), 1/4 of input size
    """

    def __init__(self, num_landmarks=29, pretrained=True):
        super().__init__()
        self.num_landmarks = num_landmarks
        self.heatmap_size = (144, 184)  # (H, W)

        self.model = smp.Unet(
            encoder_name="resnet50",
            encoder_weights="imagenet" if pretrained else None,
            in_channels=1,
            classes=num_landmarks,
            activation=None,
        )

    def forward(self, x):
        """Forward pass.

        Args:
            x: (N, 1, 576, 736) - (N, C, H, W)
        Returns:
            heatmaps: (N, 29, 144, 184) - (N, C, H, W)
        """
        x = self.model(x)
        x = nn.functional.interpolate(
            x, size=self.heatmap_size, mode='bilinear', align_corners=False
        )
        return x

    def predict_landmarks(self, x):
        """Predict landmarks from input image x using argmax on heatmaps."""
        heatmaps = self.forward(x)
        return self.decode_heatmaps(heatmaps)

    def decode_heatmaps(self, heatmaps):
        """Decode heatmaps to landmark coordinates scaled to 736x576 input size.

        Args:
            heatmaps: (N, 29, 144, 184) - (N, C, H, W)
        Returns:
            landmarks: (N, 29, 2) in 736x576 (W, H) coordinates
        """
        batch_size = heatmaps.shape[0]
        device = heatmaps.device
        landmarks = torch.zeros((batch_size, self.num_landmarks, 2), device=device)

        for b in range(batch_size):
            for lm in range(self.num_landmarks):
                hm = heatmaps[b, lm]  # (144, 184) - (H, W)
                idx = torch.argmax(hm.view(-1))
                y = idx // 184  # H
                x_coord = idx % 184  # W
                # Scale back to input size (736, 576) = (W, H)
                landmarks[b, lm, 0] = x_coord.float() * (736.0 / 184.0)  # W
                landmarks[b, lm, 1] = y.float() * (576.0 / 144.0)  # H

        return landmarks
