import csv
import json
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset


NUM_LANDMARKS = 29
NUM_CVM_STAGES = 6
INPUT_SIZE_WH = (736, 576)     # (W, H) - for display/config
INPUT_SIZE_HW = (576, 736)     # (H, W) - PyTorch convention
HEATMAP_SIZE_WH = (184, 144)  # (W, H) - for display/config
HEATMAP_SIZE_HW = (144, 184)  # (H, W) - PyTorch convention, 1/4 of INPUT
SIGMA_HEATMAP = 5.0           # NOT 3.0


def _parse_landmarks(annotations_list):
    """Extract (x, y) pairs from Aariz annotation format."""
    pts = np.zeros((NUM_LANDMARKS, 2), dtype=np.float32)
    for i, lm in enumerate(annotations_list[:NUM_LANDMARKS]):
        val = lm.get("value", {})
        pts[i, 0] = float(val.get("x", 0.0))
        pts[i, 1] = float(val.get("y", 0.0))
    return pts


def _scale_landmarks(landmarks, orig_w, orig_h, target_w, target_h):
    """Scale landmark coordinates when resizing image. CRITICAL for correct training."""
    scaled = landmarks.copy()
    scaled[:, 0] = landmarks[:, 0] * (target_w / orig_w)
    scaled[:, 1] = landmarks[:, 1] * (target_h / orig_h)
    return scaled


def generate_heatmap_vectorized(landmarks_scaled, H=144, W=184, sigma=5.0):
    """Vectorized Gaussian heatmap generation using torch (no for loops).

    Args:
        landmarks_scaled: (29, 2) in heatmap coords (W, H)
        H, W: heatmap size (144, 184) - PyTorch convention (H, W)
    Returns:
        heatmaps: (29, H, W) - (C, H, W)
    """
    C = landmarks_scaled.shape[0]
    # Create coordinate grids (H, W) each
    yy = torch.arange(H, dtype=torch.float32)
    xx = torch.arange(W, dtype=torch.float32)
    grid_y, grid_x = torch.meshgrid(yy, xx, indexing='ij')  # (H, W) each

    # Landmark coordinates: landmarks_scaled[:, 0] is W, landmarks_scaled[:, 1] is H
    cx = torch.from_numpy(landmarks_scaled[:, 0]).view(C, 1, 1)  # W coords, (C, 1, 1)
    cy = torch.from_numpy(landmarks_scaled[:, 1]).view(C, 1, 1)  # H coords, (C, 1, 1)

    # Broadcasted distance: (C, H, W)
    dist_sq = (grid_x.unsqueeze(0) - cx) ** 2 + (grid_y.unsqueeze(0) - cy) ** 2
    heatmaps = torch.exp(-dist_sq / (2 * sigma ** 2))  # (C, H, W)
    return heatmaps


class AarizDataset(Dataset):
    """PyTorch Dataset for the Aariz Cephalometric Landmark Dataset (29 landmarks).

    Ground truth = average of Senior Orthodontists + Junior Orthodontists.
    Calibration: pixel_size (mm/pixel) loaded from cephalogram_machine_mappings.csv.
    Resize: 736x576 with landmark scaling (NOT 512x512).

    Returns: (image, heatmaps, landmarks, cvm_stage, pixel_size)
        image: (1, 576, 736) - PyTorch (C, H, W)
        heatmaps: (29, 144, 184) - PyTorch (C, H, W), generated in CPU workers
        landmarks: (29, 2) in 736x576 (W, H) coords
        cvm_stage: int
        pixel_size: float (mm/pixel)
    """

    def __init__(self, dataset_folder_path: str, mode: str = "TRAIN", transform=None):
        super().__init__()
        self.dataset_path = Path(dataset_folder_path)
        self.mode = mode.upper()
        self.transform = transform

        if self.mode not in ("TRAIN", "VALID", "TEST"):
            raise ValueError("mode must be 'TRAIN', 'VALID', or 'TEST'")

        self.mode_lower = self.mode.lower()
        self.mode_path = self._find_mode_dir()

        self.images_dir = self.mode_path / "Cephalograms"
        self.senior_dir = (
            self.mode_path
            / "Annotations"
            / "Cephalometric Landmarks"
            / "Senior Orthodontists"
        )
        self.junior_dir = (
            self.mode_path
            / "Annotations"
            / "Cephalometric Landmarks"
            / "Junior Orthodontists"
        )
        self.cvm_dir = self.mode_path / "Annotations" / "CVM Stages"

        if not self.images_dir.exists():
            raise FileNotFoundError(
                f"Expected folder not found: {self.images_dir}\n"
                "Download the dataset from Figshare: https://doi.org/10.6084/m9.figshare.27986417.v1\n"
                "Then extract it so that train/, valid/, test/ folders are inside data/raw/Aariz/"
            )

        self._load_calibration()
        self.image_files = sorted(self._find_images())

    def _find_mode_dir(self):
        """Find the mode directory trying common naming conventions."""
        candidates = [
            self.dataset_path / self.mode,
            self.dataset_path / self.mode.capitalize(),
            self.dataset_path / self.mode_lower,
            self.dataset_path / self.mode_lower.replace("valid", "validation"),
        ]
        for c in candidates:
            if c.exists():
                return c
        return candidates[0]

    def _load_calibration(self):
        """Load pixel_size (mm/pixel) for each cephalogram from CSV."""
        csv_path = self.dataset_path / "cephalogram_machine_mappings.csv"
        if not csv_path.exists():
            csv_path = self.dataset_path.parent / "cephalogram_machine_mappings.csv"
        if not csv_path.exists():
            self.calibration = {}
            return

        self.calibration = {}
        with open(csv_path, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                pixel_size = float(row.get("pixel_size", 1.0))
                mode = row.get("mode", "").strip()
                if mode.upper() == self.mode:
                    self.calibration[row["cephalogram_id"].strip()] = pixel_size

    def _find_images(self):
        exts = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
        files = []
        for ext in exts:
            files.extend(self.images_dir.glob(ext))
        return files

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = self.image_files[idx]
        stem = img_path.stem

        img = cv2.imread(str(img_path), cv2.IMREAD_GRAYSCALE)
        if img is None:
            raise FileNotFoundError(f"Could not read image: {img_path}")

        orig_h, orig_w = img.shape
        landmarks = self._load_landmarks(stem)

        # Resize to 736x576 and SCALE LANDMARKS (critical!)
        img_resized = cv2.resize(img, INPUT_SIZE_WH, interpolation=cv2.INTER_LINEAR)
        landmarks_scaled = _scale_landmarks(
            landmarks, orig_w, orig_h, INPUT_SIZE_WH[0], INPUT_SIZE_WH[1]
        )

        cvm_stage = self._load_cvm(stem)
        pixel_size = self.calibration.get(stem, 1.0)

        if self.transform:
            transformed = self.transform(image=img_resized, keypoints=landmarks_scaled.tolist())
            img_resized = transformed["image"]
            landmarks_scaled = np.array(transformed["keypoints"], dtype=np.float32)

        img_tensor = torch.from_numpy(img_resized).unsqueeze(0).float()
        landmarks_tensor = torch.from_numpy(landmarks_scaled)

        # Generate heatmaps (vectorized) - done in CPU workers for parallelism
        heatmaps_tensor = generate_heatmap_vectorized(
            landmarks_scaled, H=HEATMAP_SIZE_HW[0], W=HEATMAP_SIZE_HW[1], sigma=SIGMA_HEATMAP
        )  # (29, 144, 184) - (C, H, W)

        return img_tensor, heatmaps_tensor, landmarks_tensor, cvm_stage, pixel_size

    def _load_landmarks(self, stem: str):
        senior_path = self.senior_dir / f"{stem}.json"
        junior_path = self.junior_dir / f"{stem}.json"

        senior_pts = None
        junior_pts = None

        if senior_path.exists():
            with open(senior_path, "r") as f:
                data = json.load(f)
            senior_pts = _parse_landmarks(data.get("landmarks", []))

        if junior_path.exists():
            with open(junior_path, "r") as f:
                data = json.load(f)
            junior_pts = _parse_landmarks(data.get("landmarks", []))

        # Ground truth = average of BOTH (not just Senior)
        if senior_pts is not None and junior_pts is not None:
            return (senior_pts + junior_pts) / 2.0
        elif senior_pts is not None:
            return senior_pts
        elif junior_pts is not None:
            return junior_pts
        else:
            return np.zeros((NUM_LANDMARKS, 2), dtype=np.float32)

    def _load_cvm(self, stem: str):
        cvm_path = self.cvm_dir / f"{stem}.json"
        if not cvm_path.exists():
            return 0
        with open(cvm_path, "r") as f:
            data = json.load(f)
        return int(data.get("cvm_stage", {}).get("value", 0))


def pixel_mre_to_mm(mre_pixels, pixel_size):
    """Convert MRE from pixels to millimeters using calibration. CRITICAL for clinical value."""
    return mre_pixels * pixel_size
