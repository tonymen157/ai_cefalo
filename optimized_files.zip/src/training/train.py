"""Training script for UNet+ResNet50 on Aariz dataset.

Usage:
    python src/training/train.py --config src/training/config.yaml

Optimizations applied:
    - CAPA 1: Heatmaps generated in Dataset.__getitem__() (parallel CPU workers)
    - CAPA 2: DataLoader with num_workers=4, pin_memory=True, prefetch_factor=2
    - CAPA 3: Automatic Mixed Precision (AMP) with GradScaler
    - CAPA 4: torch.compile() for 10-30% speedup
"""

import argparse
import yaml
import sys
import os
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.cuda.amp import autocast, GradScaler
import wandb

# Add src to path so we can import our modules
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.data.dataset import AarizDataset
from src.data.preprocessing import INPUT_SIZE_WH, INPUT_SIZE_HW, HEATMAP_SIZE_HW, SIGMA_HEATMAP
from src.models.unet import UNetResNet50
from src.models.losses import CombinedLoss


def load_config(config_path):
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


def create_dataloaders(config):
    """Create OPTIMIZED train/val dataloaders."""
    dataset_path = config['data'].get('dataset_path', 'data/raw/Aariz')
    batch_size = config['training']['batch_size']
    num_workers = config['data'].get('num_workers', 4)  # CAPA 2: default 4 workers

    train_ds = AarizDataset(dataset_path, mode='TRAIN')
    val_ds = AarizDataset(dataset_path, mode='VALID')

    train_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True,        # CAPA 2: faster CPU->GPU copy
        prefetch_factor=2,    # CAPA 2: pre-load 2 batches per worker
        persistent_workers=True,  # CAPA 2: don't recreate workers each epoch
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True,
        prefetch_factor=2,
        persistent_workers=True,
    )

    return train_loader, val_loader


def train_one_epoch(model, loader, criterion, optimizer, scaler, device, epoch):
    """Train one epoch with AMP (CAPA 3)."""
    model.train()
    total_loss = 0.0
    num_batches = len(loader)

    for batch_idx, (images, target_heatmaps, landmarks, cvm_stages, pixel_sizes) in enumerate(loader):
        images = images.to(device)  # (N, 1, 576, 736)
        target_heatmaps = target_heatmaps.to(device)  # (N, 29, 144, 184) - from Dataset
        landmarks = landmarks.to(device)  # (N, 29, 2) in 736x576 (W, H) coords

        optimizer.zero_grad()

        # CAPA 3: AMP with autocast
        with autocast():
            pred_heatmaps = model(images)  # (N, 29, 144, 184)
            pred_coords = model.decode_heatmaps(pred_heatmaps)  # (N, 29, 2)
            loss = criterion(pred_heatmaps, target_heatmaps, pred_coords, landmarks)

        # CAPA 3: Scaled backward
        scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()

        total_loss += loss.item()

        if batch_idx % 10 == 0:
            print(f'Epoch {epoch}, Batch {batch_idx}/{num_batches}, Loss: {loss.item():.4f}', flush=True)

    avg_loss = total_loss / num_batches
    return avg_loss


def evaluate(model, loader, criterion, device):
    """Evaluate model with clinical metrics: MRE (mm), SDR@2mm, etc."""
    model.eval()
    total_loss = 0.0
    num_batches = len(loader)

    sdr_2mm = 0
    sdr_25mm = 0
    sdr_3mm = 0
    sdr_4mm = 0
    total_landmarks = 0
    all_mre_px = []
    all_pixel_sizes = []

    with torch.no_grad():
        for images, target_heatmaps, landmarks, cvm_stages, pixel_sizes in loader:
            images = images.to(device)
            target_heatmaps = target_heatmaps.to(device)
            landmarks = landmarks.to(device)  # (N, 29, 2) in 736x576 (W, H) coords
            pixel_sizes_np = pixel_sizes.cpu().numpy() if isinstance(pixel_sizes, torch.Tensor) else np.array(pixel_sizes)

            pred_heatmaps = model(images)
            loss = criterion(pred_heatmaps, target_heatmaps)
            total_loss += loss.item()

            # Decode predicted heatmaps to coordinates (736x576 scale)
            pred_coords = model.decode_heatmaps(pred_heatmaps)  # (N, 29, 2)

            # Calculate per-landmark distances
            for b in range(len(images)):
                ps = pixel_sizes_np[b] if not isinstance(pixel_sizes_np[b], torch.Tensor) else pixel_sizes_np[b].item()
                dists_px = torch.sqrt(((pred_coords[b] - landmarks[b]) ** 2).sum(dim=1))  # (29,)
                dists_mm = dists_px.cpu().numpy() * ps

                sdr_2mm += (dists_mm <= 2.0).sum()
                sdr_25mm += (dists_mm <= 2.5).sum()
                sdr_3mm += (dists_mm <= 3.0).sum()
                sdr_4mm += (dists_mm <= 4.0).sum()
                total_landmarks += len(dists_mm)

                mre_px = dists_px.mean().item()
                all_mre_px.append(mre_px)
                all_pixel_sizes.append(ps)

    # Calculate MRE in mm (clinical metric)
    mre_mm = np.mean([mre_px * ps for mre_px, ps in zip(all_mre_px, all_pixel_sizes)])

    # Calculate SDR percentages
    sdr_2mm_pct = sdr_2mm / total_landmarks * 100 if total_landmarks > 0 else 0
    sdr_25mm_pct = sdr_25mm / total_landmarks * 100 if total_landmarks > 0 else 0
    sdr_3mm_pct = sdr_3mm / total_landmarks * 100 if total_landmarks > 0 else 0
    sdr_4mm_pct = sdr_4mm / total_landmarks * 100 if total_landmarks > 0 else 0

    avg_loss = total_loss / num_batches

    return avg_loss, mre_mm, sdr_2mm_pct, sdr_25mm_pct, sdr_3mm_pct, sdr_4mm_pct


def main():
    parser = argparse.ArgumentParser(description='Train UNet+ResNet50 for cephalometric landmarks')
    parser.add_argument(
        '--config', type=str, required=True, help='Path to config YAML'
    )
    parser.add_argument(
        '--resume', type=str, default=None, help='Checkpoint to resume from'
    )
    args = parser.parse_args()

    config = load_config(args.config)

    # Setup wandb
    wandb.init(
        project=config['wandb']['project'],
        entity=config['wandb'].get('entity'),
        name=config['wandb']['name_template'].format(
            lr=config['training']['lr'],
            batch_size=config['training']['batch_size'],
        ),
        config={
            **config['model'],
            **config['training'],
            **config['loss'],
            **config['data'],
        },
    )

    # Device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Using device: {device}', flush=True)
    if device.type == 'cuda':
        print(f'GPU: {torch.cuda.get_device_name(0)}', flush=True)

    # Model
    print('Creating model...', flush=True)
    model = UNetResNet50(
        num_landmarks=config['model']['num_landmarks'],
        pretrained=config['model']['pretrained'],
    ).to(device)

    # CAPA 4: torch.compile() for 10-30% speedup (first epoch ~2 min extra for compilation)
    print('Compiling model with torch.compile()...', flush=True)
    model = torch.compile(model)

    if args.resume:
        print(f'Resuming from {args.resume}', flush=True)
        model.load_state_dict(torch.load(args.resume, map_location=device))

    # Optimizer
    optimizer = optim.AdamW(
        model.parameters(),
        lr=config['training']['lr'],
        weight_decay=config['training']['weight_decay'],
    )

    # CAPA 3: AMP GradScaler
    scaler = GradScaler()

    # Scheduler
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=config['training']['epochs']
    )

    # Loss
    criterion = CombinedLoss(lambda_wing=config['loss']['lambda_wing'])

    # DataLoaders (optimized)
    print('Loading data...', flush=True)
    train_loader, val_loader = create_dataloaders(config)

    # Training loop
    best_val_mre = float('inf')  # Track best MRE (mm) for clinical metric

    for epoch in range(1, config['training']['epochs'] + 1):
        print(f"\n=== Epoch {epoch}/{config['training']['epochs']} ===", flush=True)

        train_loss = train_one_epoch(
            model, train_loader, criterion, optimizer, scaler, device, epoch
        )
        val_loss, val_mre_mm, val_sdr_2mm, val_sdr_25mm, val_sdr_3mm, val_sdr_4mm = evaluate(
            model, val_loader, criterion, device
        )

        # Log metrics to wandb
        wandb.log({
            'epoch': epoch,
            'train/loss': train_loss,
            'val/loss': val_loss,
            'val/MRE_mm': val_mre_mm,
            'val/SDR_2mm': val_sdr_2mm,
            'val/SDR_2.5mm': val_sdr_25mm,
            'val/SDR_3mm': val_sdr_3mm,
            'val/SDR_4mm': val_sdr_4mm,
            'lr': optimizer.param_groups[0]['lr'],
        })

        # Save best model based on clinical metric (MRE < 1.789 mm target)
        if val_mre_mm < best_val_mre:
            best_val_mre = val_mre_mm
            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_loss': val_loss,
                'val_mre_mm': val_mre_mm,
                'val_sdr_2mm': val_sdr_2mm,
                'config': config,
            }
            os.makedirs('models', exist_ok=True)
            torch.save(checkpoint, 'models/best_model.pth')
            wandb.save('models/best_model.pth')
            print(f'Saved best model at epoch {epoch}, val_MRE_mm: {val_mre_mm:.4f}, SDR@2mm: {val_sdr_2mm:.2f}%', flush=True)

        scheduler.step()

    # Save final model
    os.makedirs('models', exist_ok=True)
    torch.save(model.state_dict(), 'models/unet_final.pth')
    wandb.save('models/unet_final.pth')

    wandb.finish()
    print(f'\nTraining complete! Best val MRE (mm): {best_val_mre:.4f}', flush=True)


if __name__ == '__main__':
    main()
