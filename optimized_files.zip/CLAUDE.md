# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

AI-Cefalo is an automatic cephalometric landmark detection system for dental radiographs. Users upload a lateral skull X-ray, the AI detects 29 anatomical landmarks, calculates orthodontic angles (Steiner/Ricketts analysis), and generates a printable PDF report.

**Current state:** Fase 3 (Entrenamiento) en progreso.
- Fase 1: Completada (Estructura base, dataset Aariz, dataset.py + preprocessing.py con correcciones).
- Fase 2: Completada (Frontend + Backend expansion, commit 17ec03a).
- Fase 3: En progreso (Modelo UNet+ResNet50, train loop, pendiente corregir bugs y ejecutar entrenamiento).

## REGISTRO DE PROGRESO (2026-04-24) - SESIÓN COMPLETA

### ENTORNO Y CONFIGURACIÓN (Hecho en esta sesión):
1. **Python 3.11.9 instalado** via `winget install Python.Python.3.11` (Python 3.13 por defecto NO soportado por PyTorch).
2. **venv creado** con `Python311 -m venv venv` en raíz del proyecto.
3. **PyTorch 2.5.1+cu121** instalado con soporte CUDA 12.1 para RTX 4050 (6GB VRAM).
4. **Todas las dependencias** instaladas via `pip install -r requirements.txt` (incluye segmentation-models-pytorch, wandb, opencv, etc.).
5. **wandb configurado** con API key: `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`
   - Usuario wandb: `tonymen157-espoch-escuela-superior-politecnica-de-chimborazo`
   - Proyecto: `aicefalo`, entidad configurada en `config.yaml`.

### FASES COMPLETADAS:
- ✅ **Fase 1**: Estructura base, dataset Aariz 1000 imágenes (700/150/150), preprocesamiento completo (CLAHE → NLM → Z-score → Resize 736x576 + escalado landmarks).
- ✅ **Fase 2**: Frontend + Backend expansion (commit 17ec03a).

### FASE 3: ENTRENAMIENTO (En progreso, MÚLTIPLES FIXES APLICADOS):

**Archivos creados/modificados en esta sesión:**
- `src/models/unet.py` - **REESCRITO 3 VECES** para corregir salida de heatmaps (`nn.functional.interpolate` a (144,184)) y device mismatch.
- `src/training/train.py` - **REESCRITO 2 VECES** para corregir errores de sintaxis, dimensiones, y añadir métricas clínicas (MRE en mm, SDR).
- `src/data/preprocessing.py` - **REESCRITO** para usar convención PyTorch (H,W) = (144,184) para heatmaps.
- `src/data/dataset.py` - **MODIFICADO** para usar `INPUT_SIZE_WH`, `HEATMAP_SIZE_HW` consistentemente.
- `src/models/losses.py` - Creado en sesión anterior (WingLoss + CombinedLoss), verificado.
- `src/training/config.yaml` - Creado en sesión anterior (29 landmarks, sigma=5.0, 736x576).

**BUGS ENCONTRADOS Y CORREGIDOS (CRÍTICO PARA FUTURO YO):**
1. **Dimensión de heatmaps INCORRECTA**: `smp.Unet` mantiene tamaño espacial de entrada (576,736), pero necesitábamos (144,184). **Fix**: Añadida `nn.functional.interpolate(x, size=(144,184), mode='bilinear')` en `unet.py`.
2. **Confusión (W,H) vs (H,W)**: `HEATMAP_SIZE = (184,144)` estaba definido como (W,H), pero PyTorch usa (H,W). **Fix**: Creadas variables separadas: `HEATMAP_SIZE_WH = (184,144)` para display, `HEATMAP_SIZE_HW = (144,184)` para PyTorch.
3. **Device mismatch en decode_heatmaps**: `torch.zeros()` se creaba en CPU, causando error en WingLoss. **Fix**: `torch.zeros(..., device=heatmaps.device)` en `unet.py`.
4. **Syntax errors en train.py**: Múltiples ediciones acumularon errores de sintaxis. **Fix**: Reescritura completa del archivo.
5. **Imports incorrectos en train.py**: `from src.data.preprocessing import INPUT_SIZE, HEATMAP_SIZE` fallaba. **Fix**: Actualizado a `INPUT_SIZE_WH, INPUT_SIZE_HW, HEATMAP_SIZE_WH, HEATMAP_SIZE_HW`.

**MÉTRICAS CLÍNICAS IMPLEMENTADAS:**
- ✅ MRE en mm (usando `pixel_size` de `cephalogram_machine_mappings.csv` - CRÍTICO)
- ✅ SDR@2mm, SDR@2.5mm, SDR@3mm, SDR@4mm
- ✅ `wandb.log()` configurado para todas las métricas

**ESTADO ACTUAL (Fase 3):**
- ✅ Entrenamiento de prueba (1 época) **ejecutado con éxito** temprano en la sesión.
- 🔄 **Entrenamiento COMPLETO (200 épocas) está corriendo EN SEGUNDO PLANO** (background task: `bw7w92mg5`).
  - Comando: `venv/Scripts/python src/training/train.py --config src/training/config.yaml`
  - Config: batch_size=8, lr=1e-4, epochs=200, RTX 4050 (CUDA)
  - wandb: desactivado para prueba (`WANDB_MODE="disabled"`)
- ⚠️ **PENDIENTE**: Verificar que el entrenamiento de 200 épocas termine sin errores y revisar métricas.

### PRÓXIMOS PASOS (Fase 3 restante):
1. Esperar a que termine el entrenamiento (task `bw7w92mg5`).
2. Si hay errores: debuguear con `venv/Scripts/python -m py_compile src/training/train.py`.
3. Ejecutar con wandb activo (quitar `WANDB_MODE="disabled"`) para monitorear métricas en `wandb.ai`.
4. Evaluar en test set con `python src/training/evaluate.py --model-path models/best_model.pth`.
5. Objetivo: MRE < 1.789 mm, SDR@2mm > 78.44%.

### FASES PENDIENTES (para futuras sesiones):
4. **Fase 4**: Backend API (FastAPI), cálculo ángulos Steiner/Ricketts, generador PDF ReportLab.
5. **Fase 5**: Frontend React + Vite + Konva.js (canvas para landmarks).
6. **Fase 6**: Beta cerrada (5 estudiantes), Beta abierta (20-30), lanzamiento.

### TAREAS TÉCNICAS PENDIENTES (para refer. futura):
- Crear `src/training/evaluate.py` para evaluación en test set.
- Crear `src/api/main.py` (FastAPI), `src/api/angles.py`, `src/api/report.py`.
- Crear `frontend/` con React + Vite.
- Configurar `docker-compose.yml` para despliegue.
- Cuando el modelo esté entrenado: probar inferencia con `python src/api/predict.py --image test_image.jpg`.

## Critical Technical Decisions

- **29 landmarks** (Aariz standard), NOT 19 (ISBI 2015). All configs, models, loss functions, and metrics MUST use `NUM_LANDMARKS = 29`. No exceptions.
- **Dataset:** Aariz Cephalometric Landmark Dataset. Public, 1000 images (700/150/150 split). Clone from GitHub + download actual data from Figshare: https://doi.org/10.6084/m9.figshare.27986417.v1
- **Ground truth:** Average of BOTH Senior Orthodontists AND Junior Orthodontists annotations:
  ```
  gt_x = (senior_x + junior_x) / 2
  gt_y = (senior_y + junior_y) / 2
  ```
  NEVER use only Senior as ground truth.
- **Splits:** Use the provided TRAIN/VALID/TEST folders. NO manual `train_test_split()`. The dataset splits are already done.

## Calibration (CRITICAL)

The dataset includes `cephalogram_machine_mappings.csv` with `pixel_size` (mm/pixel) per imaging device. **MRE must be converted from pixels to millimeters using this calibration** — without it, metrics have NO clinical value.

```python
# pixel_size loaded per image from cephalogram_machine_mappings.csv
mre_mm = mre_pixels * pixel_size
```

The `AarizDataset` class returns `pixel_size` as the 4th element of each sample for this purpose.

## Preprocessing Pipeline (EXACT ORDER — NO EXCEPTIONS)

```python
# Paso 1: CLAHE (clipLimit=2.0, tileGridSize=(8,8))
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
img = clahe.apply(image)

# Paso 2: NLM denoising (h=10)
img = cv2.fastNlMeansDenoising(img, None, h=10, templateWindowSize=7, searchWindowSize=21)

# Paso 3: Z-score normalization
img = (img - img.mean()) / (img.std() + 1e-8)

# Paso 4: Resize to 736x576 WITH landmark scaling
img = cv2.resize(img, (736, 576))
landmarks[:, 0] = orig_landmarks[:, 0] * (576 / orig_w)
landmarks[:, 1] = orig_landmarks[:, 1] * (736 / orig_h)
```

**NO HorizontalFlip** in augmentation (anatomical left/right asymmetry).

## Image & Heatmap Sizes

| Parameter | Value | Notes |
|---|---|---|
| **INPUT_SIZE** | (736, 576) | (W, H) — NOT 512x512 |
| **HEATMAP_SIZE** | (184, 144) | 1/4 of INPUT_SIZE |
| **SIGMA_HEATMAP** | 5.0 | NOT 3.0 — sigma=3 too narrow for 29 landmarks |
| **NUM_LANDMARKS** | 29 | Everywhere, no exceptions |

Landmark coordinates MUST be scaled when resizing:
```python
lm_x_new = lm_x_orig * (576 / W_orig)
lm_y_new = lm_y_orig * (736 / H_orig)
```
If landmarks are not scaled, the model learns incorrect positions silently.

## Benchmarks (Official Aariz Baseline)

| Metric | Target (AI-Cefalo) | Baseline (Aariz) | SOTA (2025) |
|---|---|---|---|
| **MRE (mm)** | < 1.789 mm | 1.789 mm | < 1.23 mm |
| **SDR@2mm** | > 78.44% | 78.44% | > 81.18% |
| **SDR@2.5mm** | > 85.72% | 85.72% | > 87.28% |
| **SDR@3.0mm** | > 89.64% | 89.64% | > 90.82% |
| **SDR@4.0mm** | > 94.49% | 94.49% | > 94.82% |

## Hardware & Training

- **Train on:** RTX 4050 local (6GB VRAM). **NOT Google Colab.**
- **Batch size:** 8 max. If OOM (out of memory), reduce to 4.
- **Precision target:** MRE < 1.789 mm (clinical value requires mm conversion via calibration)

## Tech Stack

**ML/Data:** PyTorch 2.x, segmentation-models-pytorch, albumentations, OpenCV, scikit-learn, Weights & Biases (wandb)

**Backend:** Python 3.11, FastAPI + Uvicorn, ReportLab (PDF), Pillow, PostgreSQL + SQLAlchemy

**Frontend:** React + Vite, Konva.js (canvas rendering), TailwindCSS

**Infrastructure:** Docker, Railway.app (backend ~$5/mo), Vercel (frontend, free), GitHub Actions (CI/CD)

## Repository Structure

```
aicefalo/
├── data/
│   └── raw/Aariz/          # Aariz dataset (in .gitignore)
│       ├── train/           # 700 images + annotations
│       ├── valid/           # 150 images + annotations
│       ├── test/            # 150 images + annotations
│       └── cephalogram_machine_mappings.csv  # CRITICAL: pixel_size per image
├── notebooks/               # Jupyter notebooks
├── src/
│   ├── data/               # AarizDataset, preprocessing, heatmaps
│   ├── models/             # UNet, losses (WingLoss), metrics
│   ├── training/           # Train loop, evaluation, config
│   └── api/               # FastAPI, inference, angles, PDF
├── frontend/               # React app
├── tests/                  # pytest
└── models/                 # Saved checkpoints (.pth, in .gitignore)
```

## Key Architecture

```
Frontend (React) → FastAPI Backend → UNet Model (PyTorch)
                                   → Angle Calculator (Steiner: SNA, SNB, ANB)
                                   → PDF Report Generator
                                   → PostgreSQL (user credits, history)
```

**Image pipeline:** X-ray → CLAHE → NLM Denoising → Z-score → Resize 736×576 (scale landmarks!) → UNet → 29 heatmaps (184×144, sigma=5.0) → argmax + subpixel → Scale to original → Convert MRE to mm using pixel_size → Calculate angles → PDF

## Commands

```bash
# Setup (Windows - enable long path support if pip fails)
python -m venv venv
venv\Scripts\activate
pip install --no-cache-dir -r requirements.txt

# If torch install fails due to long paths, use:
pip install --no-cache-dir --target "C:/torch_lib" torch --index-url https://download.pytorch.org/whl/cpu
set PYTHONPATH=C:/torch_lib;%PYTHONPATH%

# Train (once implemented)
python src/training/train.py --config src/training/config.yaml

# Evaluate (MRE in mm using calibration)
python src/training/evaluate.py --model-path models/best_model.pth

# API locally
uvicorn src.api.main:app --reload

# Tests
pytest tests/ --cov=src --cov-report=html

# Docker
docker-compose up --build
```

## Legal/Ethical

- Position as "educational verification tool" (students verify their own analysis), NOT clinical diagnostic tool
- Delete uploaded radiographs after 1 hour
- Never store patient-identifiable data
- Required disclaimer: "AI-Cefalo is an educational support tool. Results do NOT replace certified professional diagnosis."

## Reference

Full technical plan: `AI-Cefalo_Plan_Completo.md`
Dataset paper: https://doi.org/10.1038/s41597-025-05542-3
